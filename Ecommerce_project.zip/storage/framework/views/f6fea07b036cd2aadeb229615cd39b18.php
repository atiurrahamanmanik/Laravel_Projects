

<?php $__env->startSection('title', $product->name . ' - ShopHub'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <!-- Breadcrumb -->
    <nav class="flex mb-8" aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-3">
            <li class="inline-flex items-center">
                <a href="<?php echo e(route('home')); ?>" class="text-gray-700 hover:text-indigo-600">
                    <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                    </svg>
                    Home
                </a>
            </li>
            <li>
                <div class="flex items-center">
                    <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                    </svg>
                    <a href="<?php echo e(route('shop')); ?>" class="ml-1 text-gray-700 hover:text-indigo-600 md:ml-2">Shop</a>
                </div>
            </li>
            <li>
                <div class="flex items-center">
                    <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                    </svg>
                    <a href="<?php echo e(route('shop', ['category' => $product->category->slug])); ?>" class="ml-1 text-gray-700 hover:text-indigo-600 md:ml-2">
                        <?php echo e($product->category->name); ?>

                    </a>
                </div>
            </li>
            <li aria-current="page">
                <div class="flex items-center">
                    <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                    </svg>
                    <span class="ml-1 text-gray-500 md:ml-2"><?php echo e($product->name); ?></span>
                </div>
            </li>
        </ol>
    </nav>

    <!-- Product Details -->
    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 p-6">
            <!-- Product Images -->
            <div>
                <div class="relative">
                    <img src="<?php echo e($product->image ?? 'https://via.placeholder.com/600'); ?>" 
                         alt="<?php echo e($product->name); ?>" 
                         class="w-full h-96 object-cover rounded-lg">
                    
                    <?php if($product->discount_percentage > 0): ?>
                        <div class="absolute top-4 right-4 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                            -<?php echo e($product->discount_percentage); ?>% OFF
                        </div>
                    <?php endif; ?>
                    
                    <?php if(!$product->isInStock()): ?>
                        <div class="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center rounded-lg">
                            <span class="bg-red-600 text-white px-6 py-3 rounded-lg text-xl font-bold">Out of Stock</span>
                        </div>
                    <?php endif; ?>
                </div>
                
                <?php if($product->gallery): ?>
                    <div class="grid grid-cols-4 gap-2 mt-4">
                        <img src="<?php echo e($product->image ?? 'https://via.placeholder.com/150'); ?>" 
                             class="w-full h-20 object-cover rounded cursor-pointer border-2 border-indigo-500">
                        <?php $__currentLoopData = json_decode($product->gallery); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="https://via.placeholder.com/150" 
                                 class="w-full h-20 object-cover rounded cursor-pointer hover:border-2 hover:border-indigo-500">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Product Info -->
            <div>
                <h1 class="text-3xl font-bold text-gray-800 mb-2"><?php echo e($product->name); ?></h1>
                
                <!-- Rating -->
                <div class="flex items-center mb-4">
                    <div class="flex text-yellow-400">
                        <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24">
                            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
                        </svg>
                        <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24">
                            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
                        </svg>
                        <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24">
                            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
                        </svg>
                        <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24">
                            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
                        </svg>
                        <svg class="w-5 h-5 text-gray-300 fill-current" viewBox="0 0 24 24">
                            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
                        </svg>
                    </div>
                    <span class="text-gray-600 ml-2">(4.5/5 - 128 reviews)</span>
                </div>
                
                <!-- Price -->
                <div class="mb-4">
                    <?php if($product->compare_price): ?>
                        <span class="text-3xl font-bold text-indigo-600">$<?php echo e(number_format($product->price, 2)); ?></span>
                        <span class="text-lg text-gray-500 line-through ml-2">$<?php echo e(number_format($product->compare_price, 2)); ?></span>
                        <span class="text-green-600 ml-2">Save $<?php echo e(number_format($product->compare_price - $product->price, 2)); ?></span>
                    <?php else: ?>
                        <span class="text-3xl font-bold text-indigo-600">$<?php echo e(number_format($product->price, 2)); ?></span>
                    <?php endif; ?>
                </div>
                
                <!-- Stock Status -->
                <div class="mb-4">
                    <?php if($product->isInStock()): ?>
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold bg-green-100 text-green-800">
                            <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                            </svg>
                            In Stock (<?php echo e($product->stock); ?> available)
                        </span>
                    <?php else: ?>
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold bg-red-100 text-red-800">
                            <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"/>
                            </svg>
                            Out of Stock
                        </span>
                    <?php endif; ?>
                </div>
                
                <!-- Description -->
                <div class="mb-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-2">Description</h3>
                    <p class="text-gray-600 leading-relaxed"><?php echo e($product->description); ?></p>
                </div>
                
                <!-- Product Details -->
                <div class="mb-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-2">Product Details</h3>
                    <ul class="space-y-2 text-gray-600">
                        <li class="flex items-center">
                            <svg class="w-5 h-5 text-indigo-600 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                            </svg>
                            SKU: <?php echo e($product->sku); ?>

                        </li>
                        <li class="flex items-center">
                            <svg class="w-5 h-5 text-indigo-600 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                            </svg>
                            Category: <?php echo e($product->category->name); ?>

                        </li>
                        <li class="flex items-center">
                            <svg class="w-5 h-5 text-indigo-600 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                            </svg>
                            Free Shipping on orders over $50
                        </li>
                        <li class="flex items-center">
                            <svg class="w-5 h-5 text-indigo-600 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                            </svg>
                            30-Day Return Policy
                        </li>
                    </ul>
                </div>
                
                <!-- Add to Cart Form -->
                <?php if($product->isInStock()): ?>
                    <form action="<?php echo e(route('cart.add', $product)); ?>" method="POST" class="space-y-4">
                        <?php echo csrf_field(); ?>
                        <div class="flex items-center space-x-4">
                            <div>
                                <label for="quantity" class="block text-sm font-medium text-gray-700 mb-1">Quantity</label>
                                <input type="number" 
                                       name="quantity" 
                                       id="quantity" 
                                       value="1" 
                                       min="1" 
                                       max="<?php echo e($product->stock); ?>"
                                       class="w-24 border-gray-300 rounded-lg shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            </div>
                            
                            <div class="flex-grow">
                                <button type="submit" 
                                        class="w-full bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition transform hover:scale-105">
                                    <svg class="w-5 h-5 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-1.4 1.4M17 13l1.4-1.4M5.4 5L3 3m0 0l2 2m12 8a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path>
                                    </svg>
                                    Add to Cart
                                </button>
                            </div>
                        </div>
                    </form>
                    
                    <!-- Buy Now Button -->
                    <form action="<?php echo e(route('cart.add', $product)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="quantity" value="1">
                        <button type="submit" 
                                class="w-full bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition mt-2">
                            Buy Now
                        </button>
                    </form>
                <?php endif; ?>
                
                <!-- Share Section -->
                <div class="mt-6 pt-6 border-t border-gray-200">
                    <h3 class="text-sm font-medium text-gray-800 mb-2">Share this product:</h3>
                    <div class="flex space-x-2">
                        <a href="#" class="text-gray-500 hover:text-blue-600">
                            <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.879v-6.99h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.99C18.343 21.128 22 16.991 22 12z"/>
                            </svg>
                        </a>
                        <a href="#" class="text-gray-500 hover:text-blue-400">
                            <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 0021.997-12.009c0-.21-.005-.42-.015-.63a9.935 9.935 0 002.463-2.548l-.047-.02z"/>
                            </svg>
                        </a>
                        <a href="#" class="text-gray-500 hover:text-pink-600">
                            <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.012-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Related Products -->
    <?php if($relatedProducts->count() > 0): ?>
    <div class="mt-12">
        <h2 class="text-2xl font-bold text-gray-800 mb-6">Related Products You Might Like</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition group">
                <a href="<?php echo e(route('shop.show', $related->slug)); ?>">
                    <img src="<?php echo e($related->image ?? 'https://via.placeholder.com/300'); ?>" 
                         alt="<?php echo e($related->name); ?>" 
                         class="w-full h-48 object-cover group-hover:scale-105 transition duration-300">
                </a>
                <div class="p-4">
                    <h3 class="font-semibold text-lg text-gray-800 mb-2 line-clamp-2"><?php echo e($related->name); ?></h3>
                    <div class="flex justify-between items-center">
                        <div>
                            <span class="text-xl font-bold text-indigo-600">$<?php echo e(number_format($related->price, 2)); ?></span>
                            <?php if($related->compare_price): ?>
                                <span class="text-sm text-gray-500 line-through ml-2">$<?php echo e(number_format($related->compare_price, 2)); ?></span>
                            <?php endif; ?>
                        </div>
                        <form action="<?php echo e(route('cart.add', $related)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="quantity" value="1">
                            <button type="submit" class="bg-indigo-600 text-white px-3 py-2 rounded-lg hover:bg-indigo-700 transition">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-1.4 1.4M17 13l1.4-1.4M5.4 5L3 3m0 0l2 2m12 8a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path>
                                </svg>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Product Reviews Section -->
    <div class="mt-12 bg-white rounded-lg shadow-lg p-6">
        <h2 class="text-2xl font-bold text-gray-800 mb-6">Customer Reviews</h2>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <!-- Review Summary -->
            <div class="text-center border-r border-gray-200">
                <div class="text-5xl font-bold text-indigo-600 mb-2">4.5</div>
                <div class="flex justify-center mb-2">
                    <svg class="w-5 h-5 text-yellow-400 fill-current" viewBox="0 0 24 24">
                        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
                    </svg>
                    <svg class="w-5 h-5 text-yellow-400 fill-current" viewBox="0 0 24 24">
                        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
                    </svg>
                    <svg class="w-5 h-5 text-yellow-400 fill-current" viewBox="0 0 24 24">
                        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
                    </svg>
                    <svg class="w-5 h-5 text-yellow-400 fill-current" viewBox="0 0 24 24">
                        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
                    </svg>
                    <svg class="w-5 h-5 text-gray-300 fill-current" viewBox="0 0 24 24">
                        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
                    </svg>
                </div>
                <p class="text-gray-600">Based on 128 reviews</p>
            </div>
            
            <!-- Rating Bars -->
            <div class="col-span-2">
                <div class="space-y-2">
                    <div class="flex items-center">
                        <span class="w-16 text-sm">5 star</span>
                        <div class="flex-grow mx-2">
                            <div class="h-2 bg-gray-200 rounded-full overflow-hidden">
                                <div class="h-full bg-yellow-400 rounded-full" style="width: 70%"></div>
                            </div>
                        </div>
                        <span class="w-12 text-sm text-gray-600">70%</span>
                    </div>
                    <div class="flex items-center">
                        <span class="w-16 text-sm">4 star</span>
                        <div class="flex-grow mx-2">
                            <div class="h-2 bg-gray-200 rounded-full overflow-hidden">
                                <div class="h-full bg-yellow-400 rounded-full" style="width: 15%"></div>
                            </div>
                        </div>
                        <span class="w-12 text-sm text-gray-600">15%</span>
                    </div>
                    <div class="flex items-center">
                        <span class="w-16 text-sm">3 star</span>
                        <div class="flex-grow mx-2">
                            <div class="h-2 bg-gray-200 rounded-full overflow-hidden">
                                <div class="h-full bg-yellow-400 rounded-full" style="width: 8%"></div>
                            </div>
                        </div>
                        <span class="w-12 text-sm text-gray-600">8%</span>
                    </div>
                    <div class="flex items-center">
                        <span class="w-16 text-sm">2 star</span>
                        <div class="flex-grow mx-2">
                            <div class="h-2 bg-gray-200 rounded-full overflow-hidden">
                                <div class="h-full bg-yellow-400 rounded-full" style="width: 4%"></div>
                            </div>
                        </div>
                        <span class="w-12 text-sm text-gray-600">4%</span>
                    </div>
                    <div class="flex items-center">
                        <span class="w-16 text-sm">1 star</span>
                        <div class="flex-grow mx-2">
                            <div class="h-2 bg-gray-200 rounded-full overflow-hidden">
                                <div class="h-full bg-yellow-400 rounded-full" style="width: 3%"></div>
                            </div>
                        </div>
                        <span class="w-12 text-sm text-gray-600">3%</span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Write Review Button -->
        <?php if(auth()->guard()->check()): ?>
            <div class="mt-6 text-center">
                <button class="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition">
                    Write a Review
                </button>
            </div>
        <?php else: ?>
            <div class="mt-6 text-center bg-gray-50 p-4 rounded-lg">
                <p class="text-gray-600">
                    <a href="<?php echo e(route('login')); ?>" class="text-indigo-600 hover:underline">Login</a> to write a review
                </p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/frontend/product-detail.blade.php ENDPATH**/ ?>