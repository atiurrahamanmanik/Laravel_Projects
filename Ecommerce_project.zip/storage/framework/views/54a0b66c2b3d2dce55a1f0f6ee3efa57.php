

<?php $__env->startSection('title', 'Shop - ShopHub'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="flex flex-col md:flex-row gap-8">
        <!-- Sidebar -->
        <div class="md:w-1/4">
            <div class="bg-white rounded-lg shadow-md p-4">
                <h3 class="font-bold text-lg mb-4">Categories</h3>
                <ul class="space-y-2">
                    <li>
                        <a href="<?php echo e(route('shop')); ?>" class="text-gray-600 hover:text-indigo-600 <?php echo e(!request('category') ? 'text-indigo-600 font-semibold' : ''); ?>">
                            All Products
                        </a>
                    </li>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('shop', ['category' => $category->slug])); ?>" class="text-gray-600 hover:text-indigo-600 <?php echo e(request('category') == $category->slug ? 'text-indigo-600 font-semibold' : ''); ?>">
                                <?php echo e($category->name); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        
        <!-- Products -->
        <div class="md:w-3/4">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-bold text-gray-800">Products</h2>
                <div>
                    <select class="border rounded-lg px-4 py-2" onchange="window.location.href=this.value">
                        <option value="<?php echo e(route('shop', array_merge(request()->all(), ['sort' => '']))); ?>">Default</option>
                        <option value="<?php echo e(route('shop', array_merge(request()->all(), ['sort' => 'price_asc']))); ?>" <?php echo e(request('sort') == 'price_asc' ? 'selected' : ''); ?>>
                            Price: Low to High
                        </option>
                        <option value="<?php echo e(route('shop', array_merge(request()->all(), ['sort' => 'price_desc']))); ?>" <?php echo e(request('sort') == 'price_desc' ? 'selected' : ''); ?>>
                            Price: High to Low
                        </option>
                    </select>
                </div>
            </div>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
                        <img src="<?php echo e($product->image ?? 'https://via.placeholder.com/300'); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-48 object-cover">
                        <div class="p-4">
                            <h3 class="font-semibold text-lg text-gray-800 mb-2"><?php echo e($product->name); ?></h3>
                            <p class="text-gray-600 text-sm mb-2"><?php echo e(Str::limit($product->description, 60)); ?></p>
                            <div class="flex justify-between items-center">
                                <div>
                                    <span class="text-2xl font-bold text-indigo-600">$<?php echo e(number_format($product->price, 2)); ?></span>
                                    <?php if($product->compare_price): ?>
                                        <span class="text-sm text-gray-500 line-through ml-2">$<?php echo e(number_format($product->compare_price, 2)); ?></span>
                                    <?php endif; ?>
                                </div>
                                <form action="<?php echo e(route('cart.add', $product)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="quantity" value="1">
                                    <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition">
                                        Add to Cart
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <div class="mt-8">
                <?php echo e($products->withQueryString()->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/frontend/shop.blade.php ENDPATH**/ ?>