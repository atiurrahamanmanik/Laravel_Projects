

<?php $__env->startSection('title', 'Home - ShopHub'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Hero Section -->
    <div class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
            <div class="text-center">
                <h1 class="text-5xl font-bold mb-4">Welcome to ShopHub</h1>
                <p class="text-xl mb-8">Discover amazing products at unbeatable prices</p>
                <a href="<?php echo e(route('shop')); ?>" class="bg-white text-indigo-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition inline-block">
                    Shop Now
                </a>
            </div>
        </div>
    </div>
    
    <!-- Categories -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h2 class="text-3xl font-bold text-gray-800 mb-8">Shop by Category</h2>
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('shop', ['category' => $category->slug])); ?>" class="group">
                    <div class="bg-white rounded-lg shadow-md p-4 text-center hover:shadow-lg transition">
                        <div class="text-4xl mb-2">📦</div>
                        <h3 class="font-semibold text-gray-800"><?php echo e($category->name); ?></h3>
                        <p class="text-sm text-gray-500"><?php echo e($category->products_count); ?> products</p>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
    <!-- Featured Products -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h2 class="text-3xl font-bold text-gray-800 mb-8">Featured Products</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <?php $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
                    <img src="<?php echo e($product->image ?? 'https://via.placeholder.com/300'); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-48 object-cover">
                    <div class="p-4">
                        <h3 class="font-semibold text-lg text-gray-800 mb-2"><?php echo e($product->name); ?></h3>
                        <p class="text-gray-600 text-sm mb-2"><?php echo e(Str::limit($product->description, 80)); ?></p>
                        <div class="flex justify-between items-center">
                            <div>
                                <span class="text-2xl font-bold text-indigo-600">$<?php echo e(number_format($product->price, 2)); ?></span>
                                <?php if($product->compare_price): ?>
                                    <span class="text-sm text-gray-500 line-through ml-2">$<?php echo e(number_format($product->compare_price, 2)); ?></span>
                                <?php endif; ?>
                            </div>
                            <a href="<?php echo e(route('shop.show', $product->slug)); ?>" class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition">
                                View
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
    <!-- New Arrivals -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 bg-gray-50">
        <h2 class="text-3xl font-bold text-gray-800 mb-8">New Arrivals</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <?php $__currentLoopData = $newProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
                    <img src="<?php echo e($product->image ?? 'https://via.placeholder.com/300'); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-48 object-cover">
                    <div class="p-4">
                        <h3 class="font-semibold text-lg text-gray-800 mb-2"><?php echo e($product->name); ?></h3>
                        <p class="text-gray-600 text-sm mb-2"><?php echo e(Str::limit($product->description, 80)); ?></p>
                        <div class="flex justify-between items-center">
                            <span class="text-2xl font-bold text-indigo-600">$<?php echo e(number_format($product->price, 2)); ?></span>
                            <a href="<?php echo e(route('shop.show', $product->slug)); ?>" class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition">
                                View
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/frontend/home.blade.php ENDPATH**/ ?>