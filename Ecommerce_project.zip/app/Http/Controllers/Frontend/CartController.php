<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CartController extends Controller
{
    public function index()
    {
        $cartItems = $this->getCartItems();
        $subtotal = $cartItems->sum(function ($item) {
            return $item->price * $item->quantity;
        });
        
        return view('frontend.cart', compact('cartItems', 'subtotal'));
    }
    
    public function add(Request $request, Product $product)
    {
        $request->validate([
            'quantity' => 'required|integer|min:1|max:' . $product->stock
        ]);
        
        $cart = $this->getCartQuery()
            ->where('product_id', $product->id)
            ->first();
            
        if ($cart) {
            $cart->quantity += $request->quantity;
            $cart->save();
        } else {
            Cart::create([
                'user_id' => Auth::id(),
                'session_id' => session()->getId(),
                'product_id' => $product->id,
                'quantity' => $request->quantity,
                'price' => $product->price
            ]);
        }
        
        return redirect()->route('cart.index')->with('success', 'Product added to cart successfully!');
    }
    
    public function update(Request $request, Cart $cart)
    {
        $request->validate([
            'quantity' => 'required|integer|min:1'
        ]);
        
        $cart->update(['quantity' => $request->quantity]);
        
        return redirect()->route('cart.index')->with('success', 'Cart updated successfully!');
    }
    
    public function remove(Cart $cart)
    {
        $cart->delete();
        
        return redirect()->route('cart.index')->with('success', 'Product removed from cart!');
    }
    
    public function clear()
    {
        $this->getCartQuery()->delete();
        
        return redirect()->route('cart.index')->with('success', 'Cart cleared successfully!');
    }
    
    private function getCartItems()
    {
        return $this->getCartQuery()->with('product')->get();
    }
    
    private function getCartQuery()
    {
        if (Auth::check()) {
            return Cart::where('user_id', Auth::id());
        }
        return Cart::where('session_id', session()->getId());
    }
}