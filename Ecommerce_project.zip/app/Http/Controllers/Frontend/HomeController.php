<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Category;

class HomeController extends Controller
{
    public function index()
    {
        $featuredProducts = Product::where('is_featured', true)
            ->where('is_active', true)
            ->with('category')
            ->latest()
            ->take(8)
            ->get();

    
            
        $newProducts = Product::where('is_active', true)
            ->with('category')
            ->latest()
            ->take(8)
            ->get();
            
        $categories = Category::where('is_active', true)
            ->withCount('products')
            ->take(6)
            ->get();
            
        return view('frontend.home', compact('featuredProducts', 'newProducts', 'categories'));
    }
}