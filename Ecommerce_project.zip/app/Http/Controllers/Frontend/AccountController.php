<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AccountController extends Controller
{
    public function dashboard()
    {
        $orders = Order::where('user_id', auth()->id())
            ->latest()
            ->take(5)
            ->get();
            
        return view('frontend.account.dashboard', compact('orders'));
    }
    
    public function orders()
    {
        $orders = Order::where('user_id', auth()->id())
            ->latest()
            ->paginate(10);
            
        return view('frontend.account.orders', compact('orders'));
    }
    
    public function orderDetails(Order $order)
    {
        if ($order->user_id !== auth()->id()) {
            abort(403);
        }
        
        return view('frontend.account.order-details', compact('order'));
    }
    
    public function profile()
    {
        $user = auth()->user();
        return view('frontend.account.profile', compact('user'));
    }
    
    public function updateProfile(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . auth()->id(),
            'phone' => 'nullable|string'
        ]);
        
        auth()->user()->update($request->only('name', 'email', 'phone'));
        
        return redirect()->back()->with('success', 'Profile updated successfully!');
    }
    
    public function updatePassword(Request $request)
    {
        $request->validate([
            'current_password' => 'required|current_password',
            'password' => 'required|min:8|confirmed'
        ]);
        
        auth()->user()->update([
            'password' => Hash::make($request->password)
        ]);
        
        return redirect()->back()->with('success', 'Password updated successfully!');
    }
}