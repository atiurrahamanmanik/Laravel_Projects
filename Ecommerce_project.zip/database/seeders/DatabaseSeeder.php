<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
       
        
        // ========== CREATE CATEGORIES ==========
        $categories = [
            [
                'name' => 'Electronics',
                'slug' => 'electronics',
                'description' => 'Latest electronic gadgets and devices including smartphones, laptops, headphones, and accessories. Shop the best deals on top brands.',
                'image' => 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=400',
                'is_active' => true,
            ],
            [
                'name' => 'Clothing',
                'slug' => 'clothing',
                'description' => 'Fashionable clothing for men, women, and kids. From casual wear to formal attire, find your style here.',
                'image' => 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=400',
                'is_active' => true,
            ],
            [
                'name' => 'Books',
                'slug' => 'books',
                'description' => 'Best selling books across all genres - fiction, non-fiction, educational, and more. Feed your mind with knowledge.',
                'image' => 'https://images.unsplash.com/photo-1495446815901-a7297e633e8d?w=400',
                'is_active' => true,
            ],
            [
                'name' => 'Home & Living',
                'slug' => 'home-living',
                'description' => 'Beautiful home decor, furniture, kitchenware, and garden accessories to make your living space perfect.',
                'image' => 'https://images.unsplash.com/photo-1484101403633-9e4a9e6b5c0f?w=400',
                'is_active' => true,
            ],
            [
                'name' => 'Sports & Outdoors',
                'slug' => 'sports-outdoors',
                'description' => 'Sports equipment, fitness gear, camping gear, and outdoor accessories for active lifestyles.',
                'image' => 'https://images.unsplash.com/photo-1517649763962-0c623066013b?w=400',
                'is_active' => true,
            ],
            [
                'name' => 'Beauty & Health',
                'slug' => 'beauty-health',
                'description' => 'Skincare, makeup, haircare, and health supplements. Look and feel your best every day.',
                'image' => 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=400',
                'is_active' => true,
            ],
            [
                'name' => 'Toys & Games',
                'slug' => 'toys-games',
                'description' => 'Fun toys, board games, and educational games for kids of all ages. Perfect for family time.',
                'image' => 'https://images.unsplash.com/photo-1566576912321-d58ddd7a6088?w=400',
                'is_active' => true,
            ],
            [
                'name' => 'Automotive',
                'slug' => 'automotive',
                'description' => 'Car accessories, maintenance tools, and automotive parts. Keep your vehicle in top condition.',
                'image' => 'https://images.unsplash.com/photo-1485291571150-772bcfc10da5?w=400',
                'is_active' => true,
            ],
        ];
        
        foreach ($categories as $category) {
            Category::create($category);
        }
        
        // ========== CREATE PRODUCTS ==========
        
        // Electronics Products
        $electronicsId = Category::where('slug', 'electronics')->first()->id;
        
        $electronicsProducts = [
            [
                'name' => 'iPhone 15 Pro Max',
                'slug' => 'iphone-15-pro-max',
                'description' => 'The latest iPhone with A17 Pro chip, titanium design, 48MP main camera with 24MP default, and USB-C connector. Features Dynamic Island, Always-On display, and incredible battery life.',
                'price' => 1199.99,
                'compare_price' => 1299.99,
                'stock' => 50,
                'sku' => 'APL-IP15PM-001',
                'image' => 'https://images.unsplash.com/photo-1696446702183-fbd13d77c591?w=400',
                'gallery' => json_encode(['img1.jpg', 'img2.jpg', 'img3.jpg']),
                'category_id' => $electronicsId,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'name' => 'Samsung Galaxy S24 Ultra',
                'slug' => 'samsung-galaxy-s24-ultra',
                'description' => 'Samsung Galaxy S24 Ultra with 200MP camera, S Pen included, Snapdragon 8 Gen 3 processor, and 5000mAh battery. AI-powered features for enhanced productivity.',
                'price' => 1299.99,
                'compare_price' => 1399.99,
                'stock' => 35,
                'sku' => 'SM-G928U-001',
                'image' => 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=400',
                'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
                'category_id' => $electronicsId,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'name' => 'Sony WH-1000XM5 Headphones',
                'slug' => 'sony-wh-1000xm5-headphones',
                'description' => 'Industry-leading noise cancellation with Auto NC Optimizer. 30-hour battery life, premium sound quality, and comfortable design for all-day wear.',
                'price' => 349.99,
                'compare_price' => 399.99,
                'stock' => 100,
                'sku' => 'SNY-WHXM5-001',
                'image' => 'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=400',
                'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
                'category_id' => $electronicsId,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'name' => 'MacBook Pro 14" M3',
                'slug' => 'macbook-pro-14-m3',
                'description' => 'Apple MacBook Pro with M3 chip, 14-inch Liquid Retina XDR display, 16GB RAM, 512GB SSD. Perfect for professionals and creators.',
                'price' => 1999.99,
                'compare_price' => 2199.99,
                'stock' => 25,
                'sku' => 'APL-MBP14-001',
                'image' => 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400',
                'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
                'category_id' => $electronicsId,
                'is_active' => true,
                'is_featured' => false,
            ],
            [
                'name' => 'Apple Watch Series 9',
                'slug' => 'apple-watch-series-9',
                'description' => 'Apple Watch Series 9 with S9 chip, brighter display, double tap gesture, and advanced health features including ECG and blood oxygen monitoring.',
                'price' => 399.99,
                'compare_price' => 429.99,
                'stock' => 75,
                'sku' => 'APL-WTCH9-001',
                'image' => 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=400',
                'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
                'category_id' => $electronicsId,
                'is_active' => true,
                'is_featured' => false,
            ],
            [
                'name' => 'iPad Pro 12.9"',
                'slug' => 'ipad-pro-129',
                'description' => 'iPad Pro with M2 chip, Liquid Retina XDR display, support for Apple Pencil hover, and 5G connectivity. Ultimate tablet experience.',
                'price' => 1099.99,
                'compare_price' => 1199.99,
                'stock' => 40,
                'sku' => 'APL-IPDP12-001',
                'image' => 'https://images.unsplash.com/photo-1544244015-80ddf2c8f8b5?w=400',
                'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
                'category_id' => $electronicsId,
                'is_active' => true,
                'is_featured' => false,
            ],
        ];
        
        foreach ($electronicsProducts as $product) {
            Product::create($product);
        }
        
        // Clothing Products
        $clothingId = Category::where('slug', 'clothing')->first()->id;
        
        $clothingProducts = [
            [
                'name' => 'Premium Cotton T-Shirt',
                'slug' => 'premium-cotton-t-shirt',
                'description' => '100% combed ring-spun cotton t-shirt. Soft, comfortable, and durable. Available in multiple colors. Perfect for everyday wear.',
                'price' => 29.99,
                'compare_price' => 49.99,
                'stock' => 200,
                'sku' => 'CLT-TS001-001',
                'image' => 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400',
                'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
                'category_id' => $clothingId,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'name' => 'Slim Fit Jeans',
                'slug' => 'slim-fit-jeans',
                'description' => 'Classic slim fit jeans made from premium denim. Comfortable stretch fabric for all-day wear. Perfect fit for any occasion.',
                'price' => 59.99,
                'compare_price' => 89.99,
                'stock' => 150,
                'sku' => 'CLT-JN001-001',
                'image' => 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=400',
                'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
                'category_id' => $clothingId,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'name' => 'Winter Jacket',
                'slug' => 'winter-jacket',
                'description' => 'Warm and stylish winter jacket. Water-resistant outer shell with soft inner lining. Perfect for cold weather.',
                'price' => 129.99,
                'compare_price' => 199.99,
                'stock' => 80,
                'sku' => 'CLT-JK001-001',
                'image' => 'https://images.unsplash.com/photo-1539533113208-f6df8cc8b543?w=400',
                'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
                'category_id' => $clothingId,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'name' => 'Running Shoes',
                'slug' => 'running-shoes',
                'description' => 'Lightweight running shoes with cushioned sole. Breathable mesh upper for maximum comfort during workouts.',
                'price' => 89.99,
                'compare_price' => 129.99,
                'stock' => 120,
                'sku' => 'CLT-SH001-001',
                'image' => 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400',
                'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
                'category_id' => $clothingId,
                'is_active' => true,
                'is_featured' => false,
            ],
        ];
        
        foreach ($clothingProducts as $product) {
            Product::create($product);
        }
        
        // Books Products
        $booksId = Category::where('slug', 'books')->first()->id;
        
        $booksProducts = [
            [
                'name' => 'Atomic Habits',
                'slug' => 'atomic-habits',
                'description' => 'An Easy & Proven Way to Build Good Habits & Break Bad Ones. James Clear\'s guide to creating lasting changes through small habits.',
                'price' => 19.99,
                'compare_price' => 29.99,
                'stock' => 200,
                'sku' => 'BK-ATHB-001',
                'image' => 'https://images.unsplash.com/photo-1589998059171-988d887df646?w=400',
                'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
                'category_id' => $booksId,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'name' => 'The Psychology of Money',
                'slug' => 'the-psychology-of-money',
                'description' => 'Timeless lessons on wealth, greed, and happiness. Morgan Housel shares 19 short stories exploring the strange ways people think about money.',
                'price' => 24.99,
                'compare_price' => 34.99,
                'stock' => 150,
                'sku' => 'BK-PSYM-001',
                'image' => 'https://images.unsplash.com/photo-1621351183012-e2f9972dd9bf?w=400',
                'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
                'category_id' => $booksId,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'name' => 'Deep Work',
                'slug' => 'deep-work',
                'description' => 'Rules for Focused Success in a Distracted World. Cal Newport shows how to cultivate deep work and achieve peak productivity.',
                'price' => 17.99,
                'compare_price' => 27.99,
                'stock' => 180,
                'sku' => 'BK-DPWR-001',
                'image' => 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400',
                'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
                'category_id' => $booksId,
                'is_active' => true,
                'is_featured' => false,
            ],
        ];
        
        foreach ($booksProducts as $product) {
            Product::create($product);
        }
        
        // Home & Living Products
        $homeId = Category::where('slug', 'home-living')->first()->id;
        
        $homeProducts = [
            [
                'name' => 'Smart LED Light Bulb',
                'slug' => 'smart-led-light-bulb',
                'description' => 'Wi-Fi smart LED bulb, works with Alexa and Google Home. 16 million colors, schedule and remote control via app.',
                'price' => 29.99,
                'compare_price' => 49.99,
                'stock' => 300,
                'sku' => 'HML-LED-001',
                'image' => 'https://images.unsplash.com/photo-1565814329452-e1efa11c5b89?w=400',
                'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
                'category_id' => $homeId,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'name' => 'Memory Foam Pillow',
                'slug' => 'memory-foam-pillow',
                'description' => 'Ergonomic memory foam pillow for neck pain relief. Adjustable height, cooling gel-infused for comfortable sleep.',
                'price' => 49.99,
                'compare_price' => 79.99,
                'stock' => 120,
                'sku' => 'HML-PLW-001',
                'image' => 'https://images.unsplash.com/photo-1584100936590-c7294b1aefcc?w=400',
                'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
                'category_id' => $homeId,
                'is_active' => true,
                'is_featured' => false,
            ],
        ];
        
        foreach ($homeProducts as $product) {
            Product::create($product);
        }
        
        // Add more products for other categories
        $sportsId = Category::where('slug', 'sports-outdoors')->first()->id;
        
        Product::create([
            'name' => 'Yoga Mat',
            'slug' => 'yoga-mat',
            'description' => 'Non-slip exercise yoga mat with carrying strap. Perfect for yoga, pilates, and floor exercises. Eco-friendly material.',
            'price' => 39.99,
            'compare_price' => 59.99,
            'stock' => 150,
            'sku' => 'SPT-YGM-001',
            'image' => 'https://images.unsplash.com/photo-1592432678016-e910b452f9a2?w=400',
            'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
            'category_id' => $sportsId,
            'is_active' => true,
            'is_featured' => false,
        ]);
        
        $beautyId = Category::where('slug', 'beauty-health')->first()->id;
        
        Product::create([
            'name' => 'Vitamin C Serum',
            'slug' => 'vitamin-c-serum',
            'description' => 'Anti-aging brightening vitamin C serum for face. Reduces dark spots, fine lines, and improves skin texture.',
            'price' => 34.99,
            'compare_price' => 54.99,
            'stock' => 200,
            'sku' => 'BTH-VTC-001',
            'image' => 'https://images.unsplash.com/photo-1570194065650-d99fb4b8ccb0?w=400',
            'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
            'category_id' => $beautyId,
            'is_active' => true,
            'is_featured' => true,
        ]);
        
        $toysId = Category::where('slug', 'toys-games')->first()->id;
        
        Product::create([
            'name' => 'LEGO Classic Building Set',
            'slug' => 'lego-classic-building-set',
            'description' => '450-piece LEGO classic creative building set. Stimulates creativity and imagination. Perfect gift for kids aged 4+.',
            'price' => 49.99,
            'compare_price' => 69.99,
            'stock' => 100,
            'sku' => 'TOY-LGO-001',
            'image' => 'https://images.unsplash.com/photo-1587654780291-39c9404d746b?w=400',
            'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
            'category_id' => $toysId,
            'is_active' => true,
            'is_featured' => false,
        ]);
        
        $autoId = Category::where('slug', 'automotive')->first()->id;
        
        Product::create([
            'name' => 'Car Phone Holder',
            'slug' => 'car-phone-holder',
            'description' => 'Universal air vent car phone mount. Compatible with all smartphones. Secure grip, 360-degree rotation.',
            'price' => 19.99,
            'compare_price' => 29.99,
            'stock' => 250,
            'sku' => 'AUT-PHL-001',
            'image' => 'https://images.unsplash.com/photo-1609081219090-b2f112edcec8?w=400',
            'gallery' => json_encode(['img1.jpg', 'img2.jpg']),
            'category_id' => $autoId,
            'is_active' => true,
            'is_featured' => false,
        ]);
        
        $this->command->info('Database seeded successfully!');
        $this->command->info('Categories: ' . Category::count() . ' records');
        $this->command->info('Products: ' . Product::count() . ' records');
    }
}